
<div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Select Auction For Bidding</h2>
            </div>
          </header>
<!-- Breadcrumb-->
          <ul class="breadcrumb">
            <div class="container-fluid">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active">Select Auction For Bidding</li>
            </div>
          </ul>




          <section class="tables">   
            <div class="container-fluid">
              <div class="row">
              
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-close">
                     
                    </div>
                    <div class="card-header d-flex align-items-center">
                      <h4 class="h4">Auction</h4>
                       
                       </a>
                    </div>

                      
                    <div class="card-body">
                      <table class="table table-striped table-hover">
                        <thead>

                          <tr>
                            <th>#</th>
                            <th>Title</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $i=1; foreach ($lotlist as $list) { ?>
                        <tr>
                          <td><?php echo $i; ?></td>
                          <td><?php echo $list['lot_number']; ?></td>
                          <td>

                          <button class="btn btn-<?php if($list['activate']==0){ echo "primary"; }else{ echo "success"; } ?>" onclick="window.location.href='<?php echo $action."/".$list['id_lot']."/".$list['activate']."/".$list['auction_id']; ?>'"><?php if($list['activate']==0){ echo "Activate"; }else{ echo "Close Bid"; } ?></button></td>

                          <td>
                           <?php if($list['activate']==1){ ?> <button class="btn btn-secondary" onclick="bid(<?php echo $list['id_lot'];?>)">Dashboard</button> <?php } ?>
                          </td>
                          <td>
                          <button type="button" id=" <?php echo $list['id_lot']; ?>" class="showmodal btn btn-primary">Set Time</button>
                            
                          </td>
                          <input type="hidden" id="end_date" value="<?php echo $list['lot_end_date']; ?>">
                        </tr>

                        <?php $i=$i+1; } ?>
                        </tbody>

                      </table>

                    </div>

<script type="text/javascript">
  $('.showmodal').click(function(){
    var id = $(this).attr('id');
    $('#mylotid').val(id);
    $('#myModal').modal('show');

  });
</script>


                  </div>
                </div>

            <!---dashboard start -->
            <div class="col-lg-12">
                  <div class="card">
                    <div class="card-close">
                     
                    </div>
                    <div class="card-header d-flex align-items-center">
                      <h4 class="h4">Bidding Dashboard</h4>
                       
                       </a>
                    </div>

                    <section class="dashboard-counts no-padding-bottom">
            <div class="container-fluid">
              <div class="row bg-white has-shadow">
                <!-- Item -->
                <div class="col-xl-4 col-sm-6">
                  <div class="item d-flex align-items-center">
                    <div class="icon bg-violet"><i class="icon-user"></i></div>
                    <div class="title"><span>Start Time</span>
                      <div class="progress">
                        <div role="progressbar" style="width: 25%; height: 4px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-violet"></div>
                      </div>
                    </div>
                    <div class="number" id="start_time"><strong>0</strong></div>
                  </div>
                </div>
                <!-- Item -->
                <div class="col-xl-4 col-sm-6">
                  <div class="item d-flex align-items-center">
                    <div class="icon bg-red"><i class="icon-padnote"></i></div>
                    <div class="title"><span>End Time</span>
                      <div class="progress">
                        <div role="progressbar" style="width: 25%; height: 4px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-red"></div>
                      </div>
                    </div>
                    <div class="number" id="end_time"><strong>0</strong></div>
                  </div>
                </div>
                <!-- Item -->
                <div class="col-xl-4 col-sm-6">
                  <div class="item d-flex align-items-center">
                    <div class="icon bg-green"><i class="icon-bill"></i></div>
                    <div class="title"><span>Remaining Time</span>
                      <div class="progress">
                        <div role="progressbar" style="width: 25%; height: 4px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-green"></div>
                      </div>
                    </div>
                    <div class="number" id="remaining_time"><strong>0</strong></div>
                  </div>
                </div>
                <!-- Item -->
                
              </div>
            </div>
          </section>




                    <section class="dashboard-header">
            <div class="container-fluid">
              <div class="row">
                
                <div class="col-lg-6">
                  <div class="recent-activities card">
                    <div class="card-close">
                      <div class="dropdown">
                        <button type="button" id="closeCard" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                        <div aria-labelledby="closeCard" class="dropdown-menu has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                      </div>
                    </div>
                    <div class="card-header">
                      <h3 class="h4">Recent Activities</h3>
                    </div>
                    <div class="card-body no-padding">
                      <div class="item">
                        <div class="row">
                          <div class="col-4 date-holder text-right">
                            <div class="date"><span class="text-info" id="highest">0</span></div>
                            <div class="icon"><i class="icon-clock"></i></div>
                          </div>
                          <div class="col-8 content">
                            <h5>Highest Bid</h5>
                            
                          </div>
                        </div>
                      </div>
                      <div class="item">
                        <div class="row">
                          <div class="col-4 date-holder text-right">
                            <div class="date"><span class="text-info" id="your_bid">0</span></div>
                            <div class="icon"><i class="icon-clock"></i></div>
                          </div>
                          <div class="col-8 content">
                            <h5>Your Bid</h5>
                            
                          </div>
                        </div>
                      </div>
                      <div class="item">
                        <div class="row">
                          <div class="col-4 date-holder text-right">
                            <div class="date"><span class="text-info" id="increment">xx</span></div>
                            <div class="icon"><i class="icon-clock"></i></div>
                          </div>
                          <div class="col-8 content">
                            <h5>Increment Value</h5>
                           
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-lg-6">
                  <div class="recent-activities card">
                    <div class="card-close">
                      <div class="dropdown">
                        <button type="button" id="closeCard" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                        <div aria-labelledby="closeCard" class="dropdown-menu has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                      </div>
                    </div>
                    <div class="card-header">
                      <h3 class="h4">Recent Activities</h3>
                    </div>
                    <div class="card-body no-padding">
                      <div class="item">
                        <div class="row">
                          <div class="col-4 date-holder text-right">
                            <div class="date"><span class="text-info" id="start_bid">xx</span></div>
                            <div class="icon"><i class="icon-clock"></i></div>
                          </div>
                          <div class="col-8 content">
                            <h5>Start Bid</h5>
                            
                          </div>
                        </div>
                      </div>
                      <div class="item">
                        <div class="row">
                          <div class="col-4 date-holder text-right">
                            <div class="date"><span class="text-info">Select Bidder</span></div>
                            <div class="icon"><i class="icon-clock"></i></div>
                          </div>
                          <div class="col-8 content">
                            <h5><select id="buyerId">
                              <?php foreach ($bidderList as $bidders): ?>
                                <option value="<?php echo $bidders['buyer_id'];?>"><?php echo $bidders['buyer_company_name']; ?></option>
                              <?php endforeach ?>
                              </select></h5>
                            
                          </div>
                        </div>
                      </div>
                      <div class="item">
                        <div class="row">
                          <div class="col-4 date-holder text-right">
                            <div class="date"><span class="text-info"></span></div>
                            <div class="icon"><i class="icon-clock"></i></div>
                          </div>
                          <div class="col-8 content">
                            <h5 id="dttm"></h5>
                           
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="chart col-lg-6 col-12">
                 <div class="bar-chart has-shadow bg-white">
                    <div class="title"><strong class="text-violet">Manual Bidding</strong></div><div id="status_msg" style="color: green;"></div>
                   <div class="input-group">
                                <input type="hidden" value="" id="lot_id">
                                <input type="text" class="form-control" readonly="readonly" value="100" id="manual_bid"><span class="input-group-btn">
                                  <button type="button" class="btn btn-primary" onclick="sendBid(document.getElementById('manual_bid').value)">Go!</button></span>
                              </div>
                            
                              OR
                              <br>
                              <div class="input-group">
                                <input type="text" class="form-control" value="100" id="userDefined"><span class="input-group-btn">
                                  <button type="button" class="btn btn-primary" onclick="sendBid(document.getElementById('userDefined').value)" >Go!</button></span>
                              </div>
                            
                    
                  </div>
               
                 
                  </div>
                </div>

                <div id="info"></div>
                <div class="card-header d-flex align-items-center">
                  <h3 class="h4">Activity Logs</h3>
                </div>
                <div class="showlogs"></div>


              </div>
            </div>
          </section>

                    


                  </div>
                </div>
            <!---dashboard end ---->
              </div>
            </div>
          </section>



  <!---modal --->
  <!-- Modal Form-->
                <div class="col-lg-3">
                  <div class="card">
                    <div class="card-close">
                      
                   
                    
                      <!-- Modal-->
                      <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                        <div role="document" class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 id="exampleModalLabel" class="modal-title">Add Company Here</h4>
                              <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                            </div>
                            <div class="modal-body">

                                <div class="row">
                                
                                    <label class="col-sm-12 form-control-label">Please Fill Details</label>
                                  
                                    <div class="col-sm-12">

                                    <?php echo form_open_multipart($add_time); ?>
                                    <input type="hidden" value="" id="mylotid" name="id_lot" />

                                    <div class="form-group-material">
                                      <table>
                                      <tr>
                                        <td colspan="2"><input type="text" readonly="readonly" name="lot_start_date"  class="datepicker input-material" autocomplete="off" placeholder="Select Start Date"></td>
                                        <td></td>
                                        <td>Start Time</td>
                                        <td><input type="text" placeholder="Select Time" name="lot_start_time"  class="timepicker input-material" autocomplete="off"></td>
                                      </tr>
                                      <tr>
                                        <td colspan="2"><input  type="text" readonly="readonly" placeholder="Select End Date" name="lot_end_date"  class="datepicker input-material" autocomplete="off"></td>
                                        <td></td>
                                        <td>End Time</td>
                                        <td><input  type="text" name="lot_end_time"  placeholder="Select Time" class="timepicker input-material" autocomplete="off"></td>
                                      </tr>
                                    </table>
                                                                        
                                  </div>
                                </div>
                                
                            </div>
                            <div class="modal-footer">
                              <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                              <button type="submit" class="btn btn-primary">Save</button>
                              
                            </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>        
