<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class ViewAuction extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('tank_auth');
		$this->load->model('Common_model');
	}

	function viwewlots($id)
	{
		
			$data['user_id']	= $this->tank_auth->get_user_id();
			$data['username']	= $this->tank_auth->get_username();
			$data['add_lot']	= base_url().'index.php/Manage_auctions/add_lot';
			$data['edit']	= base_url().'index.php/Manage_auctions/edit';
			$data['delete']	= base_url().'index.php/Manage_auctions/delete';
			$data['lotlist'] = $this->Common_model->getAll("tb_lot",array("auction_id"=>$id))->result_array();
			$data['action']	= base_url()."ViewAuction/activate";
			$data['bidderList'] = $this->Common_model->getAll("tb_buyers")->result_array();
			$data['add_time']= base_url()."index.php/ViewAuction/add_time";
				$this->load->view('common/header', $data);
				$this->load->view('common/nav');
				$this->load->view('selectLot',$data);
				$this->load->view('common/footer');
			
		
	}
	function add_time(){
		$data=$this->input->post();
		$data['lot_start_time'] = date('H:i:s',strtotime($data['lot_start_time']));
		$data['lot_end_time'] = date('H:i:s',strtotime($data['lot_end_time']));
		$upd = $this->Common_model->update("tb_lot",$data,array('id_lot'=>$data['id_lot']));

		$lot=$this->Common_model->getAll("tb_lot",array("id_lot"=>$data['id_lot']))->row_array();
		redirect (base_url('index.php/ViewAuction/viwewlots/'.$lot['auction_id']));
	}
	function viewBuyerLots($id)
	{
		
			$data['user_id']	= $this->tank_auth->get_user_id();
			$data['username']	= $this->tank_auth->get_username();
			$data['auction_id'] =$id;
			$data['lotlist'] = $this->Common_model->getAll("tb_lot",array("auction_id"=>$id))->result_array();
			
			
				$this->load->view('common/header', $data);
				$this->load->view('common/nav');
				$this->load->view('select_lot_for_bidders',$data);
				$this->load->view('common/footer');
			
		
	}
	function viewBiddersList($id,$lot_id)
	{
		
		$data['user_id']	= $this->tank_auth->get_user_id();
		$data['username']	= $this->tank_auth->get_username();
		$data['auction_id'] =$id;
		$data['id_lot'] = $lot_id;
		$data1 = $this->Common_model->getAllBidder("tb_buyer_invite",array("buyer_invite_auction_id"=>$id))->row_array();
		$data['data2']=explode(',', $data1['buyer_invite_buyer_id']);
		$data['add_approval']=base_url().'index.php/ViewAuction/add_approval';
		
		
		
	// 	foreach ($data['bidder_id'] as $details){
	// 	$data['fullDetail'] = $this->Common_model->getAll("tb_buyers",array('buyer_id' => $details['bidder_id']))->row_array();
	// }
		//print_r($data['fullDetail']);
			$this->load->view('common/header', $data);
			$this->load->view('common/nav');
			$this->load->view('approve_bidders',$data);
			$this->load->view('common/footer');
			
		
	}
	public function add_approval(){
		
		$data['approved_buyer_id']=implode(',', $this->input->post('buyer'));

		$data['approved_lot_id'] = $this->input->post('id_lot');

		
		$check = $this->Common_model->getAll("tb_approved",array('approved_lot_id' =>$data['approved_lot_id']))->row_array();
		 if($check!=null){
			$upd = $this->Common_model->update("tb_approved",$data,array("approved_lot_id"=>$data['approved_lot_id']));
		 }
		 else{
		 	$ins = $this->Common_model->insert("tb_approved",array('approved_lot_id' =>$data['approved_lot_id'] , 'approved_buyer_id'=>$data['approved_buyer_id']));
		 }
		

		redirect(base_url('index.php/approve_buyers'));
	}
	
	function getLots($id)
	{
		
			$data['user_id']	= $this->tank_auth->get_user_id();
			$data['username']	= $this->tank_auth->get_username();
			$data['add_lot']	= base_url().'index.php/Manage_auctions/add_lot';
			$data['edit']	= base_url().'index.php/Manage_auctions/edit';
			$data['delete']	= base_url().'index.php/Manage_auctions/delete';
			$data['lotlist'] = $this->Common_model->getAll("tb_lot",array("auction_id"=>$id))->result_array();
			$data['action']	= base_url()."ViewAuction/activate";
			$data['bidderList'] = $this->Common_model->getAll("tb_buyers")->result_array();
				$this->load->view('common/header', $data);
				$this->load->view('common/nav');
				$this->load->view('getLots',$data);
				$this->load->view('common/footer');
			
		
	}
	function generateReport($id,$lot)
	{
		
			
			$data['lotlist'] = $this->Common_model->getAllJoin("tb_lot",array("auction_id"=>$id,"id_lot"=>$lot))->result_array();
			
				$this->load->view('common/header', $data);
				$this->load->view('common/nav');
				$this->load->view('report',$data);
				$this->load->view('common/footer');
			
		
	}
	function activate($id,$stat,$auction)
	{
		if($stat==0){ $stat=1; }elseif($stat==1){ $stat=0; }
		$this->Common_model->update("tb_lot",array("activate"=>$stat),array("id_lot"=>$id));
		redirect(base_url().'ViewAuction/viwewlots/'.$auction);

	}

	function getAuctionData()
	{
		$id=$this->input->post('id_lot');
		$info= $this->Common_model->getAuctionData($id);
		echo json_encode($info);
		//return $data;
		//echo "You requested data for ".$id;
		// $this->Common_model->getAll("get_auc",array("activate"=>$stat),array("id_lot"=>$id));
		// redirect(base_url().'ViewAuction/viwewlots/'.$auction);

	}
	function biddingData()
	{
		$id=$this->input->post('id_lot');
		$info= $this->Common_model->getAll("tb_bidding",array("lot_id"=>$id),"DESC","bidding_price")->row_array();
		echo json_encode($info);
		
	}
	function insertBid()
	{

		$data=$this->input->post();
		//$data['buyer_id']= $this->tank_auth->get_user_id();
		$data['bid_time'] = date('Y-m-d H:i:s');
		$info= $this->Common_model->insert("tb_bidding",$data);
		if($info > 0){ echo "success"; }else{ echo "failed"; }
		
		
	}

	function getMyBid(){
		$data=$this->input->post();
		$info= $this->Common_model->getAll("tb_bidding",array("lot_id"=>$data['id_lot'],"buyer_id"=>$data['buyer_id']),"DESC","bidding_price")->row_array();
		echo json_encode($info);
	}

	function getLogs()
	{
		

		$data=$this->input->post();
		$info= $this->Common_model->getAll("tb_bidding",array("lot_id"=>$data['id_lot']),"DESC","bidding_price",10)->result_array();
		$i=0;
		?>
		<table class="table table-striped">
		<thead>
                          <tr>
                            <th>#</th>
                            <th>Highest Bid</th>
                            <th>Bidder ID</th>
                            <th>Time of Bid</th>
                          </tr>
                        </thead>
                        <tbody>
		<?php
		foreach($info as $in)
		{
			$name = $this->Common_model->getAll("tb_buyers",array("buyer_id"=>$in['buyer_id']))->row_array();

			?>
				
                        
                          <tr>
                            <th scope="row"><?php echo $i=$i+1; ?></th>
                            <td><?php echo $in['bidding_price']; ?></td>
                            <td><?php echo $name['buyer_company_name']; ?></td>
                            <td><?php echo $in['bid_time']; ?></td>
                          </tr>
                         
                        
			<?php

		}
		?>
		</tbody>
                      </table>
                      <?php
		
	}


	
}