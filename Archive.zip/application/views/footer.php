<!-- footer section -->
<footer class="footer">
  <div class="container">
    <div class="col-md-6 left">
      <h4>Let's work together</h4>
      <p> Call: xxx.xxx.xxxx OR Email : <a href="mailto:ashokbhatt@nnbid.com"> ashokbhatt@nnbid.com </a></p>
    </div>
    <div class="col-md-6 right">
      <p>© 2017 All rights reserved.<br>
        Made with <i class="fa fa-heart pulse"></i> by <a href="http://www.nnbid.com/">NNBID</a></p>
    </div>
  </div>
</footer>
<!-- footer section --> 

<!-- JS FILES --> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<script src="<?php echo base_url('assets/'); ?>js/bootstrap.min.js"></script> 
<script src="<?php echo base_url('assets/'); ?>js/jquery.fancybox.pack.js"></script> 
<script src="<?php echo base_url('assets/'); ?>js/retina.min.js"></script> 
<script src="<?php echo base_url('assets/'); ?>js/modernizr.js"></script> 
<script src="<?php echo base_url('assets/'); ?>js/main.js"></script>
</body>
</html>