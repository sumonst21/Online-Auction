<!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>NNBID Company Name &copy; 2017</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a href="https://bootstrapious.com/admin-templates" class="external">Bootstrapious</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- Javascript files-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="<?php echo asset_url(); ?>js/jquery-ui.js"></script>
    <script src="<?php echo asset_url(); ?>js/tether.min.js"></script>
    <script src="<?php echo asset_url(); ?>js/bootstrap.min.js"></script>
    <script src="<?php echo asset_url(); ?>js/jquery.cookie.js"> </script>
    <script src="<?php echo asset_url(); ?>js/jquery.validate.min.js"></script>
    <script src="<?php echo asset_url(); ?>js/front.js"></script>

    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID.-->
    <script>
  $( function() {
    $( ".datepicker" ).datepicker();
  } );
  </script>

    <!---->
<script type="text/javascript">
  var timer;
  function bid(id){

      //window.location.href="#dashboard_start";
      clearInterval(timer);
      for(i=0; i<100; i++)
      {
        window.clearInterval(i);
      }
      
      $.ajax({
                type: 'POST',
                url: "<?php echo base_url(); ?>index.php/ViewAuction/allinone",
                data: {lot_id:id},
                cache: false,
                success: function(resultData) 
                { 
                  if(resultData != 0)
                  {
                    var obj = $.parseJSON(resultData);
                    $("#start_time").text(obj.starttime);
                    $("#end_time").text(obj.endtime);
                    $("#start_bid").text(obj.startbid);
                    $("#increment").text(obj.increment);
                    $("#your_bid").text(obj.yourbid);
                    $("#rank").text(obj.yourrank);
                    $("#highest").text(obj.highestbid);
                    $("#manual_bid").val(obj.bidprice);
                    if(obj.yourrank!=1)
                    {
                      $('.chart').show();
                    }
                    else
                    {
                      $('.chart').hide();
                    }
                    getTimeRemaining(obj.enddate+" "+obj.endtime,id);
                  }
                  else{
                     for(i=0; i<100; i++)
                      {
                        window.clearInterval(i);
                      }
                      
                      $("#dashboard_bidding_main").hide();
                      alert("Bidding is closed !!");
                      }
    
                }
          });
    }

    function getTimeRemaining(endtime,id)
    {

      var countDownDate = new Date(endtime).getTime();
      // Update the count down every 1 second
      timer = setTimeout(function() {
          // Get todays date and time
          var now = new Date().getTime();
          // Find the distance between now an the count down date
          var distance = countDownDate - now;
          // Time calculations for days, hours, minutes and seconds
          var days = Math.floor(distance / (1000 * 60 * 60 * 24));
          var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
          var seconds = Math.floor((distance % (1000 * 60)) / 1000);
          // Output the result in an element with id="demo"
          document.getElementById("remaining_time").innerHTML =  hours + ":"
          + minutes + ":" + seconds;
          bid(id);
          // If the count down is over, write some text 
              if (distance < 0) {
                document.getElementById("remaining_time").innerHTML = "EXPIRED";
                  clearInterval(timer);
                $("#dashboard_bidding_main").hide();
               // alert("Bidding is closed !!");
              }
              
        }, 1000);
    }


     function sendBid(amount)
     {
      if (amount==0) {
       return false;
      }
      else if(amount > +($("#highest").text()))
      {

          $.ajax({
                type: 'POST',
                url: "<?php echo base_url(); ?>index.php/ViewAuction/insertBid",
                data: {lot_id:$('.startbid').attr('id'),bidding_price:amount},
                cache: false,
                success: function(resultData) { 
                  if(resultData=='success')
                  {
                    $('.chart').hide();
                  }
                  // alert("Bidd Succesful with value: "+amount);
                 // $("#status_msg").text("Bid Successful with price: "+amount);
                  //bid($('.startbid').attr('id'));

              }
          });
      }
      else{
        $("#status_msg").text("Amount Must Be greater Than  "+$("#highest").text());
      }
    }
</script>

  </body>
</html>